Panopoly Pages
==============
Helps create and manage pages that can be Panelized!

Key Features
* Creation of a "Content Page" content type for basic page management
* Creation of a "Landing Page" workflow for landing page creation
* Panelizer integration for all view modes of the "Content Page" 
